import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import je.util.Turtle;
import javax.swing.border.TitledBorder;

public class Halbjahresleistung extends JFrame {
  // Anfang Attribute
  // start attributes
  private JLabel l1Klassenarbeit1 = new JLabel();
  private JNumberField t1 = new JNumberField();
  private JButton bNeu = new JButton();
  private JLabel l2Klassenarbeit1 = new JLabel();
  private JNumberField t2 = new JNumberField();
  private JButton bRechnen = new JButton();
  private JLabel lMuendlicheNote1 = new JLabel();
  private JNumberField t3 = new JNumberField();
  private JButton bBeenden = new JButton();
  private JLabel lNotendurchschnitt1 = new JLabel();
  private JNumberField r1 = new JNumberField();
  private JTextField r2 = new JTextField();
  private JLabel lZeugnisnote1 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private ImageIcon jLabel1Icon = new ImageIcon(getClass().getResource("images/Zeugnis.gif"));
  private JLabel lHalbjaresleistungsRechner1 = new JLabel();
  private JLabel lvonAeron1 = new JLabel();
  // end attributes
  // Ende Attribute
  public Halbjahresleistung() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 455; 
    int frameHeight = 409;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("Halbjahresleistung");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    cp.setBackground(Color.WHITE);
    // start components
    // Anfang Komponenten
    l1Klassenarbeit1.setBounds(40, 96, 112, 24);
    l1Klassenarbeit1.setText("1. Klassenarbeit:");
    cp.add(l1Klassenarbeit1);
    // t1
    t1.setBounds(176, 96, 64, 24);
    cp.add(t1);
    //bNeu
    bNeu.setBounds(296, 96, 96, 24);
    bNeu.setText("Neu");
    bNeu.setMargin(new Insets(2, 2, 2, 2));
    bNeu.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bNeu_ActionPerformed(evt);
      }
    });
    cp.add(bNeu);
    // l2Klassenarbeit1
    l2Klassenarbeit1.setBounds(40, 136, 112, 24);
    l2Klassenarbeit1.setText("2. Klassenarbeit:");
    cp.add(l2Klassenarbeit1);
    // t2
    t2.setBounds(176, 136, 64, 24);
    cp.add(t2);
    // bRechnen
    bRechnen.setBounds(296, 136, 96, 24);
    bRechnen.setText("Berechnen");
    bRechnen.setMargin(new Insets(2, 2, 2, 2));
    bRechnen.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bRechnen_ActionPerformed(evt);
      }
    });
    cp.add(bRechnen);
    //t3
    t3.setBounds(176, 176, 64, 24);
    bBeenden.setBounds(296, 176, 96, 24);
    cp.add(t3);
    // lMuendlicheNote1
    lMuendlicheNote1.setBounds(40, 176, 112, 24);
    lMuendlicheNote1.setText("Mündliche Note:");
    cp.add(lMuendlicheNote1);
    // bBeenden
    bBeenden.setText("Beenden");
    bBeenden.setMargin(new Insets(2, 2, 2, 2));
    bBeenden.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bBeenden_ActionPerformed(evt);
      }
    });
    cp.add(bBeenden);
    // lNotendurchschnitt1
    lNotendurchschnitt1.setBounds(168, 256, 112, 24);
    lNotendurchschnitt1.setText("Notendurchschnitt:");
    cp.add(lNotendurchschnitt1);
    // r1
    r1.setBounds(296, 256, 96, 24);
    r1.setEditable(false);
    r1.setText("-");
    cp.add(r1);
    // r2
    r2.setBounds(296, 296, 96, 24);
    r2.setEditable(false);
    r2.setText("-");
    cp.add(r2);
    // lZeugnisnote1
    lZeugnisnote1.setBounds(168, 296, 112, 24);
    lZeugnisnote1.setText("Zeugnisnote:");
    cp.add(lZeugnisnote1);
    // jLabel1
    jLabel1.setBounds(40, 232, 88, 112);
    jLabel1.setText("");
    jLabel1.setIcon(jLabel1Icon);
    cp.add(jLabel1);
    // lHalbjaresleistungsRechner1
    lHalbjaresleistungsRechner1.setBounds(24, 16, 400, 60);
    lHalbjaresleistungsRechner1.setText("Halbjaresleistungs Rechner");
    lHalbjaresleistungsRechner1.setFont(new Font("Dialog", Font.BOLD + Font.ITALIC, 30));
    cp.add(lHalbjaresleistungsRechner1);
    // lvonAeron1 
    lvonAeron1.setBounds(376, 344, 64, 24);
    lvonAeron1.setText("von Aeron");
    lvonAeron1.setFont(new Font("Dialog", Font.ITALIC, 12));
    cp.add(lvonAeron1);
    // Ende Komponenten
    // end components
    setVisible(true);
    t1.setHorizontalAlignment(SwingConstants.CENTER);
    t2.setHorizontalAlignment(SwingConstants.CENTER);
    t3.setHorizontalAlignment(SwingConstants.CENTER);
    r1.setHorizontalAlignment(SwingConstants.CENTER);
    r2.setHorizontalAlignment(SwingConstants.CENTER);
  } // end of public Halbjahresleistung
  
  // Anfang Methoden
  
  // start methods
  public static void main(String[] args) {
    new Halbjahresleistung();
  } // end of main
  
  // Buttons
  
  public void bNeu_ActionPerformed(ActionEvent evt) {
    t1.setText(null);
    t2.setText(null);
    t3.setText(null);
    r1.setText("-");
    r2.setText("-");
  } // end of bNeu_ActionPerformed

  public void bRechnen_ActionPerformed(ActionEvent evt) {
    if(t1.getInt() >= 0 && t1.getInt() <= 15 && (t2.getInt() >= 0 && t2.getInt() <= 15) && (t3.getInt() >= 0 && t3.getInt() <= 15)) {
      r1.setFloat(dNote());
      r2.setText(zNote());
    }else {
      r1.setText("-");
      r2.setText("Fehler");
    } // end of if-else
  } // end of bRechnen_ActionPerformed

  public void bBeenden_ActionPerformed(ActionEvent evt) {
    System.exit(0);
  } // end of bBeenden_ActionPerformed
  
  // other Methods
  
  public float dNote() {
    float schnittKlArb = (t1.getInt() + t2.getInt()) / 2;
    float sGesamt = (3 * schnittKlArb + t3.getInt()) / 4;
    return sGesamt;
  }
  
  public String zNote() {
    String schulnote;
    float schnittGesamt = this.dNote();
        
    if(schnittGesamt>=12.5) {
      schulnote = "sehr gut";
    } else if(schnittGesamt>=9.5) {
      schulnote = "gut";
    } else if (schnittGesamt>=6.5) {
      schulnote = "befriedigend";
    } else if (schnittGesamt>=3.5) {
      schulnote = "ausreichend";
    } else if (schnittGesamt>=0.5) {
      schulnote = "mangelhaft";
    } else {
      schulnote = "ungenügend";
    }
    return schulnote;
  } 
  // Ende Methoden
  // end methods
} // end of class Halbjahresleistung
